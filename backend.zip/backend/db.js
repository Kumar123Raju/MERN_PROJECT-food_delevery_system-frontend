const mongoose = require('mongoose')
// 2uF7jMOCELYcpzDv
// const mongoDbClient = require("mongodb").MongoClient
const mongoURI = 'mongodb+srv://2021pgcaca021:2uF7jMOCELYcpzDv@cluster0.2nuz0qm.mongodb.net/Gofoodmern' // Customer change url to your db you created in atlas
// mongodb://<username>:<password>@merncluster-shard-00-00.d1d4z.mongodb.net:27017,merncluster-shard-00-01.d1d4z.mongodb.net:27017,merncluster-shard-00-02.d1d4z.mongodb.net:27017/?ssl=true&replicaSet=atlas-eusy5p-shard-0&authSource=admin&retryWrites=true&w=majority

const mongoDB=async()=>{
  try{
    await mongoose.connect(mongoURI,{
  useNewUrlParser:true,
  useUnifiedTopology:true,
});
console.log('connected to mongoDB');
// fetch data
const MyModel=await mongoose.connection.db.collection("foodData2");
const data=await MyModel.find({}).toArray();

// fetch food catagory
const foodCategory=await mongoose.connection.db.collection("foodCategory");
const catData=await foodCategory.find({}).toArray();
global.foodData2=data;
global.foodCategory=catData;
// console.log(global.foodCategory);

// console.log(global.foodData2);




  }catch(err){
    console.log(err);
  }
}
module.exports=mongoDB;
  